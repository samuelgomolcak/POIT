﻿using System;
using UnityEngine;
using WebSocketSharp;

public class WebSocketClient : MonoBehaviour
{
    /*
     * URL
     */
    [SerializeField] private string url = "wss://";

    /*
     * WebSocket
     */
    public static WebSocketClient Instance;
    private WebSocket webSocket;

    /*
     * TIME AND ID MANAGEMENT
     */
    private const int SAMPLING_INTERVAL = 200;
    private float timeLastMessage = 0f;
    private int messageId = 0;

    /*
     * CONNECT IMMEDIATELY ON AWAKE
     */
    private void Awake()
    {
        if (Instance == null)
            Instance = this;
        else
            Destroy(this);
        
        webSocket = new WebSocket(url);

        ConnectClient();
    }

    /*
     * CONNECTING + ADDING LISTENERS
     */
    private void ConnectClient()
    {
        webSocket.OnOpen += OnOpen;
        webSocket.OnClose += OnClose;
        webSocket.OnError += OnError;
        
        webSocket.Connect ();
    }

    /*
     * WS EVENT - ON ONPEN
     */
    private void OnOpen(object sender, EventArgs e)
    {
        Debug.Log("WebSocketClient: Connection opened");
    }

    /*
     * WS EVENT - ON ERROR
     */
    private void OnError(object sender, ErrorEventArgs e)
    {
        Debug.Log("WebSocketClient: ERROR: " + e.Message);
    }

    /*
     * WS EVENT - ON CLOSE
     */
    private void OnClose(object sender, CloseEventArgs e)
    {
        Debug.Log("WebSocketClient: Connection closed");
        
        webSocket.OnOpen -= OnOpen;
        webSocket.OnClose -= OnClose;
        webSocket.OnError -= OnError;
    }

    /*
     * SEND DATA ON UPDATE (SAMPLING_INTERVAL)
     */
    private void Update()
    {
        if (((Time.time * 1000) - timeLastMessage >= SAMPLING_INTERVAL) ||
            (timeLastMessage == 0))
        {
            MessageData messageData = new MessageData();
            messageData.id = messageId;
            messageData.deltaTime = SAMPLING_INTERVAL;
            messageData.position[0] = this.transform.position.x;
            messageData.position[1] = this.transform.position.y;
            messageData.position[2] = this.transform.position.z;

            string messageString = JsonUtility.ToJson(messageData);

            Debug.Log("WebSocketClient: SENDING: " + messageString);
            webSocket.Send(messageString);

            timeLastMessage = Time.time * 1000;
            messageId++;
        }        
    }

    /*
     * CLOSE CONNECTION ON DESTROY
     */
    private void OnDestroy()
    {
        webSocket.Close();
    }
}

/*
* MESSAGE DATA TEMPLATE
*/
public class MessageData
{
    public int id;
    public int deltaTime;
    public float[] position = new float[3];
}
